<script src="<?= SRC ?>/vendor/apexcharts/apexcharts.min.js"></script>
<script src="<?= SRC ?>/vendor/bootstrap/js/bootstrap.bundle.min.js"></script>
<script src="<?= SRC ?>/vendor/chart.js/chart.umd.js"></script>
<script src="<?= SRC ?>/vendor/echarts/echarts.min.js"></script>
<script src="<?= SRC ?>/vendor/quill/quill.js"></script>
<script src="<?= SRC ?>/vendor/simple-datatables/simple-datatables.js"></script>
<script src="<?= SRC ?>/vendor/tinymce/tinymce.min.js"></script>
<script src="<?= SRC ?>/vendor/php-email-form/validate.js"></script>

<!-- Template Main JS File -->
<script src="<?= SRC ?>/assets/jquery.min.js"></script>

<script src="https://cdn.jsdelivr.net/npm/select2@4.1.0-rc.0/dist/js/select2.min.js"></script>
<script src="<?= SRC ?>/js/main.js?id=<?= uniqid() ?>"></script>
<script src="<?= SRC ?>/assets/jquery.mask.js"></script>
<script src="<?= SRC ?>/js/masks.js?id=<?= uniqid() ?>"></script>
<script src="<?= SRC ?>/js/index.js?id=<?= uniqid() ?>"></script>
