# sistema-agendamento-academia

DIREITO SITE

MUDAR NO  TEXTO

a criação do curso de Direito e foi reformado no ano de 2018 para melhor
 -> a criação do curso de Direito e foi reformado no ano de 2025 para melhor

NO REGULAMENTO - JUNTAR O ANTIGO COM O NOVO ADICIONAR O LINK DO REGULAMENTO


Daniel Salume Silva (Coordenador) -> JAKELINE MARTINS SILVA ROCHA (coordenadora)


TIRAR

REVISTAS DIREITO -> TIRAR TUDO
CÂMARA ARBITRAL -> TIRAR TUDO

Horários de Atendimento:

SEGUNDA 08h às 12h
TERÇA 14h:30 às 18h:30
QUARTA 14h:30 às 18h:30
QUINTA 08h às 12h



NO REGULAMENTO - JUNTAR O ANTIGO COM O NOVO



Sócio proprietário da MALVERDI & LIMA ADVOGADOS. Atua há 15 anos em Direito Civil (contratos, família, sucessões, imóveis), Bancário, Administrativo e Constitucional.