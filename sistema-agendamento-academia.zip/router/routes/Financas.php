<?php

$Financas = [
    "/admin/financeiro" => "FinancasController@index",
    "/admin/financeiro/registrar-pagamento" => "FinancasController@registrar_pagamento",
    "/admin/financeiro/editar-pagamento" => "FinancasController@editar_pagamento",
    "/admin/financeiro/deletar-pagamento" => "FinancasController@deletar_pagamento",
];

